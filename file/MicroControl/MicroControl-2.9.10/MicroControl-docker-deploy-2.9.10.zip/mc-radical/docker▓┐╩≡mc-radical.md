docker部署mc-radical

 

---------------------------------
#(x.1)配置文件
  (x.x.1)修改配置文件appsettings.json并拷贝到宿主机
 

#(x.2)创建容器并运行
(--name 容器名称，可自定义)
(--restart=always 自动重启)
(-v /etc/localtime:/etc/localtime)挂载宿主机localtime文件解决容器时间与主机时区不一致的问题
(-v $PWD/data:/data 将主机中当前目录下的data挂载到容器的/data)
(--net=host 网络直接使用宿主机网络)（-p 6022:6022 端口映射）

cd /root/docker/mc/mc-radical

docker run --name=mc-radical --restart=always -d \
-v /etc/localtime:/etc/localtime \
-v $PWD/appsettings.json:/root/app/appsettings.json \
-v $PWD/Logs:/root/app/Logs  \
serset/mc-radical
 

 


 
#---------------------------------------
#常用命令

#查看容器logs
docker logs mc-radical

#在容器内执行命令行
docker exec -it mc-radical bash

#停止容器
docker stop mc-radical

#打开容器
docker start mc-radical

#重启容器
docker restart mc-radical


#删除容器
docker rm mc-radical -f

docker rmi serset/mc-radical

 




