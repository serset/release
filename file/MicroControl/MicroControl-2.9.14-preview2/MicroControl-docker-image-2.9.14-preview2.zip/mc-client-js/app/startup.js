﻿/*

//(x.1)register logger.onmessage

//type: info/error
//e: pass error when type is error
//function(message,type,e){ }
vit.logger.onmessage = function (message, type, e) {
	if (e) message = message + '\n' + e.stack;

	console.log(message);
};



//(x.2)register localApiService.onError

//(Error e,requestData_bytes,rpcData,replyRpcDta)
//localApiService.onError = function(e,requestData_bytes,rpcData,replyRpcDta){ return {success：false}; }
serviceStation.localApiService.onError = function (e, requestData_bytes, rpcData, replyRpcDta) {
	vit.logger.error(e);
	var reply = {
		success: false,
		error: {
			errorMessage: e.message,
			errorDetail: { name: e.name, stack: e.stack }
		}
	};
	return reply;
};




//(x.3)register onDisconnected to serviceCenter
serviceStation.org.event_onDisconnected = function () {
	vit.logger.info('[sers.CL]org.event_onDisconnected');
	
	setTimeout(()=>{
		vit.logger.info('process exiting...');
		process.exit();
	},0);
};

*/




//(x.4) import controllers
require('/root/app/controllers.js');


