﻿
//(x.1)import websocket and sers
WebSocket = require('isomorphic-ws');
require('/root/main/sers.ServiceStation.min.js');



//(x.2)register logger.onmessage

//type: info/error
//e: pass error when type is error
//function(message,type,e){ }
vit.logger.onmessage = function (message, type, e) {
	if (e) message = message + '\n' + e.stack;

	console.log(message);
};




//(x.3)create serviceStation
apiNodes = [];

serviceStation = new sers.ServiceStation();




//(x.4)register localApiService.onError

//(Error e,requestData_bytes,rpcData,replyRpcDta)
//localApiService.onError = function(e,requestData_bytes,rpcData,replyRpcDta){ return {success：false}; }
serviceStation.localApiService.onError = function (e, requestData_bytes, rpcData, replyRpcDta) {
    vit.logger.error(e);
    var reply = {
        success: false,
        error: {
            errorMessage: e.message,
            errorDetail: { name: e.name, stack: e.stack }
        }
    };
    return reply;
};




//(x.5)register onDisconnected to serviceCenter
serviceStation.org.event_onDisconnected = function () {
	vit.logger.info('[sers.CL]org.event_onDisconnected');
	
	setTimeout(()=>{
		vit.logger.info('process exiting...');
		process.exit();
	},0);
};



//(x.6)import app
appsettings = require('/root/app/appsettings.json');
require('/root/app/startup.js');



//(x.7)connect to serviceCenter
try {
    vit.logger.info('');
    vit.logger.info('--------------------------------------------');

    //(x.x.1)load localApi
    vit.logger.info('[ApiLoader] load localApi...'); 
 
    serviceStation.localApiService.clearApiNodes();

    for (var item of apiNodes) {
        serviceStation.localApiService.addSimpleApiNode(item.route, item.httpMethod.toUpperCase(), item.name, item.description, item.onInvoke);
    }
    vit.logger.info('loaded localApi，count：' + apiNodes.length);


    //(x.x.2)load configuration
    vit.logger.info('load configuration...');

    //set websocket host
    serviceStation.org.setHost(appsettings.CL.host);

    //连接秘钥，用以验证连接安全性。服务端和客户端必须一致
    serviceStation.org.secretKey = appsettings.CL.secretKey;

    serviceStation.serviceStationInfo = appsettings.serviceStationInfo;


    //(x.x.3)connect
    serviceStation.start();

} catch (e) {
    vit.logger.error(e);
}
