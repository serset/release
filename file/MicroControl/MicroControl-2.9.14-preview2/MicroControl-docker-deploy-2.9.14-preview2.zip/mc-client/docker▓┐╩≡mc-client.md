docker部署mc-client

 

---------------------------------
#(x.1)配置文件
  (x.1)把本文件所在目录中的Data拷贝到宿主机
  (x.2)修改配置文件 appsettings.json
 

#(x.2)创建容器并运行
(--name 容器名称，可自定义)
(--restart=always 自动重启)
(-v /etc/localtime:/etc/localtime)挂载宿主机localtime文件解决容器时间与主机时区不一致的问题
(-v $PWD/data:/data 将主机中当前目录下的data挂载到容器的/data)
(--net=host 网络直接使用宿主机网络)（-p 6022:6022 端口映射）

cd /root/docker/mc/mc-client

docker run --name=mc-client --restart=always -d \
-v /:/host --privileged \
--net=host \
-v /etc/localtime:/etc/localtime \
-v $PWD/appsettings.json:/root/app/appsettings.json \
-v $PWD/mcc-linux.json:/root/app/mcc-linux.json \
-v $PWD/Logs:/root/app/Logs  \
serset/mc-client
 


-v $PWD/sers.api.shell.json:/root/app/sers.api.shell.json \


 
#---------------------------------------
#常用命令

#查看容器logs
docker logs mc-client

#在容器内执行命令行
docker exec -it mc-client bash

#停止容器
docker stop mc-client

#打开容器
docker start mc-client

#重启容器
docker restart mc-client


#删除容器
docker rm mc-client -f

docker rmi serset/mc-client

 




