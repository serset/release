﻿//------------------------------------------------------------------------
//(x.1) call api
serviceStation.apiClient.callApiAsync("/JsStation/api1", { name: 'sers' }, 'GET',
    function ({ success, replyData_bytes, replyRpcData_object }) {
        if (!success) {
            vit.logger.info("接口调用失败！");
            return;
        }
        //var str = vit.bytesToString(replyData_bytes);
        //var apiRet = vit.bytesToObject(replyData_bytes);
        vit.logger.info("接口调用成功。 reply:" + vit.bytesToString(replyData_bytes));
    });



//------------------------------------------------------------------------
//(x.2)apiInvokeArray
/* 
    // apiInvoke  {route: '/JsStation/api', httpMethod: 'GET', name: 'call api in js server', description: 'js作为服务站点', onInvoke,onInvokeAsync}
    //      onInvoke:   (requestData_bytes,rpcData_object,replyRpcData_object)=>{ return replyData_bytes; }	 //onInvoke 和 onInvokeAsync 指定其一即可
    //      onInvokeAsync:   (requestData_bytes,rpcData_object,replyRpcData_object,onInvokeFinish)=>{ }
    //					    onInvokeFinish :(replyData_bytes)=>{ }

    //onInvoke demo:
    var apiInvoke = {
        route: '/JsStation/api', httpMethod: 'GET', name: 'call api in js server', description: 'js作为服务站点',
            onInvoke: function (requestData_bytes, rpcData_object, replyRpcData_object) {
                var request_string = vit.bytesToString(requestData_bytes);
                vit.logger.info('[api调用] request:' + request_string);

                var replyData = {
                    success: true,
                    data: {
                        request_string: request_string,
                        _: Math.random()
                    }
                };
                return vit.objectSerializeToBytes(replyData);
            }
    }

    //onInvokeAsync demo:
    var apiInvoke = {
        route: '/JsStation/api', httpMethod: 'GET', name: 'call api in js server', description: 'js作为服务站点',
            onInvokeAsync: function (requestData_bytes, rpcData_object, replyRpcData_object,onInvokeFinish) {
                var request_string = vit.bytesToString(requestData_bytes);
                vit.logger.info('[api调用] request:' + request_string);

                var replyData = {
                    success: true,
                    data: {
                        request_string: request_string,
                        _: Math.random()
                    }
                };
                var replyData_bytes = vit.objectSerializeToBytes(replyData);
                setTimeout(()=>{       onInvokeFinish(replyData_bytes);         },1000);
            }
    }
//*/
apiInvokeArray.push(
    {
        route: '/JsStation/api', httpMethod: 'GET', name: 'call api in js server', description: 'js作为服务站点',
        onInvoke: function (requestData_bytes, rpcData_object, replyRpcData_object) {
            var request_string = vit.bytesToString(requestData_bytes);
            vit.logger.info('[api调用] request:' + request_string);

            var replyData = {
                success: true,
                data:
                {
                    request_string: request_string,
                    _: Math.random()
                }
            };
            return vit.objectSerializeToBytes(replyData);
        }
    });