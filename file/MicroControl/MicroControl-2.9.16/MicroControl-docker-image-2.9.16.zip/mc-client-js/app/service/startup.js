﻿/*

//(x.x.1)register logger.onmessage
//type: info/error
//e: pass error when type is error
//function(message,type,e){ }
vit.logger.onmessage = function (message, type, e) {
    if (e) message = message + '\n' + e.stack;

    console.log(message);
};

//(x.x.2)register localApiService.onError
//(Error e,requestData_bytes,rpcData_object,replyRpcData_object)
//localApiService.onError = (e,requestData_bytes,rpcData_object,replyRpcData_object)=>{ return {success:false}; }
serviceStation.localApiService.onError = function (e, requestData_bytes, rpcData_object, replyRpcData_object) {
    vit.logger.error(e);
    var reply = {
        success: false,
        error: {
            errorMessage: e.message,
            errorDetail: { name: e.name, stack: e.stack }
        }
    };
    return reply;
};
*/


//(x.x.3)register onDisconnected from serviceCenter
serviceStation.org.event_onDisconnected = function () {
	vit.logger.info('[sers.CL]org.event_onDisconnected');
	
	setTimeout(()=>{
		vit.logger.info('process exiting...');
		process.exit();
	},10000);
};






//(x.x.4) import controllers
require('./controllers.js');


