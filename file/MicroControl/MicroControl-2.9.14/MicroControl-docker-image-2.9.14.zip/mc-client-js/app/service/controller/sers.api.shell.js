﻿/*
   apiNodes demo:
   //onInvoke:   function(requestData_bytes,rpcData_object,reply_rpcData_object){}
	{
		route: '/JsStation/api1', httpMethod: 'GET', name: 'call api in js server',description: 'js作为服务站点',
		onInvoke: function (requestData_bytes, rpcData, reply_rpcData) {
			var request_string = vit.bytesToString(requestData_bytes);
			vit.logger.info('[api调用] request:' + request_string);

			var replyData = {
				success: true,
				data:{
					request_string: request_string,
					_: Math.random()
				}
			};
			return vit.objectSerializeToBytes(replyData);
		}
	}
*/

var process = require('child_process');
var shell = require('../../sers.api.shell.json');

var apiStation = appsettings.Sers?.LocalApiService?.apiStationNames ? (appsettings.Sers.LocalApiService.apiStationNames[0]) : '';
var routePrefix = appsettings.mcc?.routePrefix || '';

if (shell && shell.apis) {
	for (var apiConfig of shell.apis) {
		try {
			addApi(apiConfig);
		} catch (e) {
			vit.logger.error(e);
		}
	}
}



function addApi(apiConfig) {
	var route = apiConfig.route.replace(/\{\{apiStation\}\}/g, apiStation).replace(/\{\{routePrefix\}\}/g, routePrefix);
	var strInput = JSON.stringify(apiConfig.input);

	var formatInput = (input, apiArg) => { return input; };
	var formatOutput = (output, apiArg, error) => {
		if (apiConfig.input.useApiReturn) {
			return { success: error ? false : true, data: output, error: error };
		}
		else {
			if (error == null) return output;
			return { success: false, error: error };
		}
	};

	if (apiConfig.formatInput) {
		try {
			formatInput = eval(apiConfig.formatInput);
		} catch (e) {
			vit.logger.error(e);
		}
	}
	if (apiConfig.formatOutput) {
		try {
			formatOutput = eval(apiConfig.formatOutput);
		} catch (e) {
			vit.logger.error(e);
		}
	}

	function execShell(apiArg) {

		//(x.2)formatInput
		var input = strInput.replace(/\{\{apiArg\}\}/g, apiArg);
		input = eval('(' + input + ')');
		input = formatInput(input, apiArg);

		//(x.3)Execuse shell
		var output, error;
		try {
			if (input.WorkingDirectory) {
				var arguments = ['-c', 'cd "' + input.WorkingDirectory + '"; ' + input.fileName + ' ' + (input.arguments || '')];
			} else {
				var arguments = ['-c', input.fileName + ' ' + (input.arguments || '')];
			}

			//vit.logger.info("sh -c "+ input.fileName + ' ' + (input.arguments || '') );
			var result = process.spawnSync('sh', arguments);

			//vit.logger.info("stdout: "+ result.stdout?.toString());
			//vit.logger.info("stderr: " + result.stderr?.toString());
			//vit.logger.info("error: " + result.error?.toString());

			if (result.status == 0) {
				output = result.stdout?.toString();
			} else {
				error = {
					errorMessage: result.stderr?.toString(),
					errorDetail: { status: result.status, error: result.error?.toString() }
				};
			}
		} catch (e) {
			vit.logger.error(e);
			error = {
				errorMessage: e.message,
				errorDetail: { name: e.name, stack: e.stack }
			};
		}

		//(x.4)formatOutput
		output = formatOutput(output, apiArg, error);

		return output;
	}



	apiInvokeArray.push({
		route: route, httpMethod: apiConfig.extendConfig?.httpMethod || 'POST', name: apiConfig.name, description: apiConfig.description,
		onInvoke: function (requestData_bytes, rpcData, reply_rpcData) {
			var request_string = vit.bytesToString(requestData_bytes);
			//vit.logger.info('[api调用] request:' + request_string);

			var output = execShell(request_string);
			return vit.objectSerializeToBytes(output);
		}
	}); 

}


