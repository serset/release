﻿
require('./controller/sers.api.shell');



//(x.1)add api startNextStep

//apiInvokeArray.push({
//	route: '/FlowTea.TaskProcessor/Step/StartNextStep', httpMethod: 'POST', name: 'startNextStep', description: '{taskData:{},taskStepId:"01"}',
//	onInvokeAsync: function (requestData_bytes, rpcData_object, replyRpcData_object, onInvokeFinish) {
//		var request_string = vit.bytesToString(requestData_bytes);
//		//vit.logger.info('[api调用] request:' + request_string);
//		debugger;
//		var args = eval('(' + request_string + ')');
//		var taskData = args.taskData;
//		var taskStepId = args.taskStepId;

//		startNextStep(taskData, taskStepId).then((apiRet) => {
//			var replyData_bytes = vit.objectSerializeToBytes(apiRet);
//			onInvokeFinish(replyData_bytes);
//		});
//	}
//});
 