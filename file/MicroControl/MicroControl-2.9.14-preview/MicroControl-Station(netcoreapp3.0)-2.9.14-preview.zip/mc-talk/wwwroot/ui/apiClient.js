/* apiClient.js
 * Date   : 2020-11-04
 * Version: 1.2
 * author : Lith
 * email  : sersms@163.com
 */



// apiClient
; (function () {



    var apiClient = window.apiClient = {};



    /*
     apiClient.ajax({
            url: 'http://a.com/a',
            type: 'POST',
            data: {},
            success: function (apiRet) {

                if (!apiRet || apiRet.success != true) {
                    var msg = '操作失败!<br/>';
                    if (apiRet.error) msg += apiRet.error.errorMessage;
                    ui.alert(msg);
                    return;
                }
                var rows = apiRet.data.rows;

                $scope.$applyAsync();
            }
        });     
     
    apiClient.ajax({
        url: 'http://a.com/a',
        type: 'POST',   // GET、POST、PUT、DELETE 等
        headers:{},
        data: {},
        dataType: 'form',  // urlencoded、form、json
        cache:false,
        async: false,
        success: function (apiRet) {            
        }
    });
    */
    /**  
     * @param {any} param
     * 
     * dataType:    urlencoded（对应application/x-www-form-urlencoded）
     *              form      （对应multipart/form-data）
     *              json      （对应application/json）
     * 
     * type:        GET          （data放在url中传参）
     *              POST、PUT    （dataType默认为json）              
     *              其他如 DELETE（dataType默认为urlencoded）
     *
     */
    //  apiClient.ajax({ url:'http://a.com/a',type:'POST',data:{},success:function(apiRet){ } });
    //  apiClient.ajax({ url:'/a',type:'POST',headers:{},dataType:'urlencoded',data:{}, cache:false,async: false,success:function(apiRet){ } });
    apiClient.ajax = function ajax(param) {

        var type = param.type || 'GET', data = param.data;
        type = type.toUpperCase();       

        //(x.1) 处理get请求
        if (type == 'GET') {
            var urlParam = null;
            if (typeof (data) == 'object') {
                urlParam = {};
                for (var k in data) {
                    var v = data[k];
                    if (typeof (v) == 'undefined') continue;
                    if (v == null) {
                        urlParam[k] = '';
                        continue;
                    }
                    if (typeof (v) != 'string') {
                        urlParam[k] = JSON.stringify(v);
                    }else
                        urlParam[k] = v;
                }
            }
            return $.ajax({
                type: type,
                url: param.url,      
                data: urlParam,                         
                // 允许跨域
                crossDomain: true,
                cache: param.cache,
                async: param.async,
                headers: param.headers,
                success: param.success
            });            
        }

        //(x.2)get default dataType by type
        var dataType = param.dataType;     
        if (!dataType) {
            var defaultDataType = {
                POST: 'json', PUT: 'json'
            };

            dataType = defaultDataType[type] || 'urlencoded';
        }


        //(x.3.1)json
        if (dataType == 'json') {
            if (typeof (data) != 'string') {
                data = JSON.stringify(data);
            }
            return $.ajax({
                type: type,
                url: param.url,
                contentType: 'application/json',// 默认是："application/x-www-form-urlencoded"
                data: data,

                // 允许跨域
                crossDomain: true,
                cache: param.cache,
                async: param.async,
                headers: param.headers,
                success: param.success
            });         
        }

        //(x.3.2)form
        if (dataType == 'form') {
        
            //var  formData=buildFormData( {a:1,b:[{b1:new Date()}]})
            function buildFormData(data) {
                var formData = new window.FormData(), key;
                data = data || {};               
                for (key in data) {
                    if (data.hasOwnProperty(key)) {
                        var val = data[key];
                        addFieldToFormData(formData, val, key);
                    }
                }
                return formData;


                /**                
                    $.type(true) === "boolean"
                    $.type(3) === "number"
                    $.type("test") === "string"
                    $.type(function(){}) === "function"
                    $.type([]) === "array"
                    $.type({a:1}) === "object"
                    $.type(new Date()) === "date"
                    $.type(/test/) === "regexp"
                 * 
                 */
                function isDate(val) {
                    return $.type(val) === 'date';
                    //return val instanceof Date;                     
                }
                function isString(val) {
                    return $.type(val) === 'string';
                    //return 'string'===typeof (val);
                }
                function isObject(val) {
                    return $.type(val) === 'object';                     
                }
                function isArray(val) {
                    return $.type(val) === 'array';
                }
                function isFile(file) {
                    return file != null && (file instanceof window.Blob || (file.flashId && file.name && file.size));
                };

                
                function addFieldToFormData(formData, val, key) {
                    if (val !== undefined) {
                        if (isDate(val)) {
                            val = val.toISOString();
                        }
                        if (isString(val)) {
                            formData.append(key, val);
                        } else if (isFile(val)) {
                            //var file = toResumeFile(val, formData);
                            var file = val;
                            var split = key.split(',');
                            if (split[1]) {
                                file.ngfName = split[1].replace(/^\s+|\s+$/g, '');
                                key = split[0];
                            }
                            //config._fileKey = config._fileKey || key;
                            formData.append(key, file, file.ngfName || file.name);
                        } else {
                            if (isObject(val) || isArray(val)) {
                                if (val.$$ngfCircularDetection) throw 'addFieldToFormData: Circular reference in data. Make sure specified data has no circular reference: ' + key;

                                val.$$ngfCircularDetection = true;
                                try {
                                    for (var k in val) {
                                        if (val.hasOwnProperty(k) && k !== '$$ngfCircularDetection') {
                                            var objectKey = '[i]';
                                            addFieldToFormData(formData, val[k], key + objectKey.replace(/[ik]/g, k));
                                        }
                                    }
                                } finally {
                                    delete val.$$ngfCircularDetection;
                                }
                            } else {
                                formData.append(key, val);
                            }
                        }
                    }
                }
            }


            //var fd = new FormData()
            //fd.append('file', a)
            //$.ajax({
            //    type: "POST",
            //    url: "xxx",
            //    data: fd,
            //    processData: false,//重要
            //    contentType: false,//重要
            //    success: function (data) {  
            //    }
            //})

            var formData = buildFormData(data);
            return $.ajax({
                type: type,
                url: param.url,
                //contentType: "multipart/form-data",
                data: formData,
                processData: false,//重要
                contentType: false,//重要
                // 允许跨域
                crossDomain: true,
                cache: param.cache,
                async: param.async,
                headers: param.headers,
                success: param.success
            }); 
        }

        //(x.3.3)urlencoded
        return $.ajax({
            type: type,           
            url: param.url,
            contentType:"application/x-www-form-urlencoded",
            data: data,
            // 允许跨域
            crossDomain: true,
            cache: param.cache,
            async: param.async,
            headers: param.headers,
            success: param.success
        });    
       
    };


    




})();








