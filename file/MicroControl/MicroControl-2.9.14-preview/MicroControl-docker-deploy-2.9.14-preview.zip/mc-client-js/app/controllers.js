﻿/*
   apiNodes demo:
   //onInvoke:   function(requestData_bytes,rpcData_object,reply_rpcData_object){}
	{
		route: '/JsStation/api1', httpMethod: 'GET', name: 'call api in js server',description: 'js作为服务站点',
		onInvoke: function (requestData_bytes, rpcData, reply_rpcData) {
			var request_string = vit.bytesToString(requestData_bytes);
			vit.logger.info('[api调用] request:' + request_string);

			var replyData = {
				success: true,
				data:{
					request_string: request_string,
					_: Math.random()
				}
			};
			return vit.objectSerializeToBytes(replyData);
		}
	}
*/

var process = require('child_process');


//(x.1)add api ShellWithReturn
apiNodes.push({
	route: '/MCC/RedRemote/Shell/ShellWithReturn', httpMethod: 'POST', name: 'run shell in server', description: '{fileName:"ifconfig",arguments:["-a"]}',
	onInvoke: function (requestData_bytes, rpcData, reply_rpcData) {
		var request_string = vit.bytesToString(requestData_bytes);
		//vit.logger.info('[api调用] request:' + request_string);

		var args = eval('(' + request_string + ')');
		var replyData,result = process.spawnSync(args.fileName, args.arguments);

		if (result.status==0) {
			replyData = {
				success: true,
				data: result.stdout?.toString()
			};
		} else {
			replyData = {
				success: false,
				error: {
					errorMessage: result.stderr?.toString(),
					errorDetail: {status:result.status, error:result.error?.toString() }
				}
			};
		}
		
		return vit.objectSerializeToBytes(replyData);
	}
});
