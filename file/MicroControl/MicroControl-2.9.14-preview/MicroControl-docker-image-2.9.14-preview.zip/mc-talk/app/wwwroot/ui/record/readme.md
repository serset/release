# 浏览器HTML5录音功能

https://blog.csdn.net/weixin_34032621/article/details/88901783

https://github.com/silenceboychen/recording