Sers CGateway v1.2.0

--------------------------------------------
说明：



1. 开发环境：Ubuntu eclipse c++   
    运行环境：Linux




2. linux运行脚本：

cd /root/netapp/CGateway

chmod  -R 777  ./Gateway

 ./Gateway





 