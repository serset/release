infoGet 2.0.1(2020-02-19)

http://localhost:4570/infoGet/widget/demo/demo.html